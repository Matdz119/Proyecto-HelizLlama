"""Adaptadores de Ollama para LLMPort (Mistral 7B) y EmbeddingPort (BGE-M3)."""
import httpx


class OllamaLLM:
    def __init__(self, base_url: str, model: str, temperature: float, num_ctx: int, timeout: float):
        self.base_url, self.model = base_url.rstrip("/"), model
        self.options = {"temperature": temperature, "num_ctx": num_ctx}
        self.timeout = timeout

    async def generate(self, system: str, user: str) -> str:
        payload = {"model": self.model, "stream": False, "options": self.options,
                   "messages": [{"role": "system", "content": system},
                                {"role": "user", "content": user}]}
        async with httpx.AsyncClient(timeout=self.timeout) as client:
            r = await client.post(f"{self.base_url}/api/chat", json=payload)
            r.raise_for_status()
            return r.json()["message"]["content"]


class OllamaEmbedder:
    def __init__(self, base_url: str, model: str, timeout: float = 120.0):
        self.base_url, self.model, self.timeout = base_url.rstrip("/"), model, timeout

    async def embed(self, texts: list[str]) -> list[list[float]]:
        async with httpx.AsyncClient(timeout=self.timeout) as client:
            r = await client.post(f"{self.base_url}/api/embed", json={"model": self.model, "input": texts})
            r.raise_for_status()
            return r.json()["embeddings"]


async def ollama_models(base_url: str) -> list[str]:
    async with httpx.AsyncClient(timeout=10) as client:
        r = await client.get(f"{base_url.rstrip('/')}/api/tags")
        r.raise_for_status()
        return [m["name"] for m in r.json().get("models", [])]
