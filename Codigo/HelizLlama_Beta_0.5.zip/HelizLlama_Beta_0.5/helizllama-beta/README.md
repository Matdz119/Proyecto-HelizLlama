# HelizLlama – Beta 0.5

Asistente conversacional RAG para Moodle. Repositorio con tres partes:

| Carpeta | Qué es | Se ejecuta en |
|---|---|---|
| `orchestrator/` | Orquestador RAG en FastAPI con arquitectura hexagonal + PostgreSQL/pgvector | Legion (Docker) |
| `moodle/local/helizllama/` | Plugin local: servicios AJAX, cliente HTTP, indexación, eventos, tareas, informes | Servidor Moodle |
| `moodle/blocks/helizllama/` | Bloque del curso: panel de chat (Mustache + JS AMD) y botones Útil / No útil | Servidor Moodle |
| `openclaw/` | Skill opcional para usar HelizLlama como herramienta de solo lectura desde OpenClaw | Opcional |

```
Navegador ──HTTPS──▶ Moodle (block + local) ──Tailscale, token──▶ Orquestador :8000 ──▶ Ollama :11434 (Mistral 7B, BGE-M3)
                                                                         └──▶ PostgreSQL + pgvector (red interna de Docker)
```

## 0. Inicio rápido: Consola de pruebas (sin Moodle ni Docker)

Requisitos: Ollama con `mistral` y `bge-m3` (`ollama pull mistral`, `ollama pull bge-m3`).

```powershell
cd orchestrator
powershell -ExecutionPolicy Bypass -File .\iniciar_consola.ps1
# Por Tailscale:
powershell -ExecutionPolicy Bypass -File .\iniciar_consola.ps1 -OllamaUrl http://100.x.y.z:11434
```

Abre http://localhost:8090. También puedes usar **Terminal → Run Task → HelizLlama: iniciar consola** en VS Code.
La consola usa el mismo núcleo RAG (umbral, prompt, fuentes) con un almacén en memoria.

> Si el proyecto está dentro de OneDrive, pausa la sincronización mientras se crea `.venv`
> o mueve la carpeta a `C:\Dev\helizllama-beta`.

## 1. Preparar la Legion (IA)

```powershell
ollama pull mistral
ollama pull bge-m3
ollama list
```

Ollama ya escucha en el puerto 11434. El plugin **no** debe llamar a Ollama: solo el orquestador lo usa.
Como Ollama no tiene autenticación, limita el puerto 11434 en las ACL de Tailscale (o déjalo solo en `localhost`
si el orquestador corre en la misma Legion, que es la configuración por defecto).

## 2. Levantar el orquestador

```powershell
cd orchestrator
copy .env.example .env
python -c "import secrets; print(secrets.token_urlsafe(32))"   # pega el valor en HZ_API_TOKEN
docker compose up -d --build
curl http://localhost:8000/v1/health
```

`/v1/health` debe mostrar `database: ok`, `ollama: ok` y `models_ready: true`.
Desde el servidor Moodle prueba `curl http://100.x.y.z:8000/v1/health` con la IP de Tailscale de la Legion.

Para desarrollar sin Docker: crea un entorno virtual en `orchestrator/`, instala `requirements.txt`, cambia
`HZ_OLLAMA_URL=http://localhost:11434` y `HZ_DATABASE_URL` a tu PostgreSQL, y ejecuta
`uvicorn app.api.main:app --reload`. Las pruebas del dominio no necesitan Ollama ni base de datos: `pytest`.

## 3. Instalar los plugins en Moodle

En Moodle 5.1 o superior el código web está en la carpeta `public/`:

```
<moodle>/public/local/helizllama   ← moodle/local/helizllama
<moodle>/public/blocks/helizllama  ← moodle/blocks/helizllama
```

(En Moodle 5.0 o anterior, sin la carpeta `public/`.) Luego:

1. Entra como administrador y completa la instalación desde **Notificaciones**.
2. **Administración del sitio → Plugins → Plugins locales → Asistente HelizLlama**: URL `http://100.x.y.z:8000`,
   el mismo token del `.env`, umbral `0.45` y top-k `5`. Usa **Verificar el estado del orquestador**.
3. **Configura el cron** (obligatorio: la indexación y la reindexación son tareas de Moodle).
   Linux: `* * * * * /usr/bin/php <moodle>/admin/cli/cron.php`. Windows: Programador de tareas cada minuto con
   `php.exe <moodle>\admin\cli\cron.php`. Para probar rápido: `php admin/cli/adhoc_task.php --execute`.
4. En un curso, activa la edición y agrega el bloque **Asistente HelizLlama**.
5. Abre **HelizLlama: índice del curso** (menú del curso o enlace del bloque) y pulsa **Indexar el contenido del curso ahora**.
6. Pregunta en el bloque, por ejemplo: "¿Cuándo se entrega la tarea 2?".

No hace falta activar los servicios web para la app móvil: el bloque usa AJAX con la sesión de Moodle.

## Cómo se cumplen las historias del backlog

| HU / HT | Dónde está |
|---|---|
| HU-01 consulta con citas | `local_helizllama_ask` → `POST /v1/ask` → `AskService` |
| HU-02 indexación manual e índice en sombra | `manage.php` → tarea `index_course` → `IndexService` (versión `building` → `active`, rollback a `failed`) |
| HU-03 reindexación automática | `db/events.php` + tarea ad hoc deduplicada + `daily_sync` |
| HU-04 configuración | `settings.php` (token enmascarado, umbral validado 0–1) y `health.php` |
| HU-05 ausencia de información | Umbral en `AskService`: sin fragmentos relevantes no se llama al LLM |
| HU-06 seguimiento docente | `report.php` sobre `local_helizllama_log` (sin `userid`) |
| HU-07 / HT-11 mediación pedagógica | `domain/prompt.py` (solo lectura, citas, recomendación, palabras clave para biblioteca) |
| HU-08 Útil / No útil | `local_helizllama_feedback` vía AJAX |
| HT-04 hexagonal | `domain/ports.py` + `adapters/` |
| HT-08 seguridad | Token Bearer en el orquestador + capacidades de Moodle |
| HT-09 Tailscale | Comunicación plugin → orquestador por IP 100.x.y.z |
| RNF-10 RAGAS | Tabla `hz_interaction` con pregunta, contextos y respuesta |

## Limitaciones de esta beta

- Cada cambio reindexa el curso completo en una versión nueva (simple y transaccional, pero lento en cursos grandes).
- La extracción de PDF escaneados (imágenes) no funciona sin OCR.
- La cola de inferencia atiende una pregunta a la vez (`HZ_MAX_CONCURRENT_INFERENCES=1`); las demás esperan hasta 60 s.
- El orquestador usa HTTP dentro de Tailscale (el túnel ya va cifrado con WireGuard); para exponerlo fuera del tailnet usa HTTPS.
- El historial del chat no se guarda entre recargas de página.
- `amd/build/chat.min.js` es una copia sin minificar; para producción ejecuta `grunt amd` en Moodle.
- Pendientes para próximos sprints: script de evaluación RAGAS (HT-05) y Dataset Ground Truth (HT-12).
