"""VectorStorePort sobre PostgreSQL + pgvector con versiones de índice por curso."""
import json

import psycopg
from pgvector.psycopg import register_vector_async
from psycopg_pool import AsyncConnectionPool

from ..domain.models import Chunk, RetrievedChunk


class PgVectorStore:
    def __init__(self, dsn: str):
        self.pool = AsyncConnectionPool(dsn, min_size=1, max_size=5, open=False,
                                        configure=register_vector_async)

    async def open(self):
        await self.pool.open()

    async def close(self):
        await self.pool.close()

    async def ping(self) -> bool:
        async with self.pool.connection() as conn:
            await conn.execute("SELECT 1")
        return True

    async def search(self, course_id: int, embedding: list[float], top_k: int) -> list[RetrievedChunk]:
        # El filtro por course_id es obligatorio: aislamiento entre cursos (RNF-06).
        sql = """SELECT c.course_id, c.resource_id, c.resource_name, c.resource_url, c.resource_type,
                        c.chunk_index, c.content, 1 - (c.embedding <=> %s::vector) AS score
                   FROM hz_chunk c JOIN hz_index_version v ON v.id = c.version_id
                  WHERE c.course_id = %s AND v.status = 'active'
               ORDER BY c.embedding <=> %s::vector LIMIT %s"""
        async with self.pool.connection() as conn:
            rows = await (await conn.execute(sql, (embedding, course_id, embedding, top_k))).fetchall()
        return [RetrievedChunk(Chunk(*r[:7]), float(r[7])) for r in rows]

    async def create_version(self, course_id: int) -> int:
        async with self.pool.connection() as conn:
            row = await (await conn.execute(
                "INSERT INTO hz_index_version (course_id, status) VALUES (%s, 'building') RETURNING id",
                (course_id,))).fetchone()
        return row[0]

    async def add_chunks(self, version_id: int, chunks: list[Chunk]) -> None:
        async with self.pool.connection() as conn:
            async with conn.cursor() as cur:
                await cur.executemany(
                    """INSERT INTO hz_chunk (version_id, course_id, resource_id, resource_name, resource_url,
                                             resource_type, chunk_index, content, embedding)
                       VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
                    [(version_id, c.course_id, c.resource_id, c.resource_name, c.resource_url,
                      c.resource_type, c.chunk_index, c.content, c.embedding) for c in chunks])

    async def activate_version(self, course_id: int, version_id: int) -> None:
        async with self.pool.connection() as conn:
            async with conn.transaction():
                await conn.execute("UPDATE hz_index_version SET status='retired' "
                                   "WHERE course_id=%s AND status='active'", (course_id,))
                await conn.execute("UPDATE hz_index_version SET status='active', activated_at=now(), "
                                   "chunks=(SELECT count(*) FROM hz_chunk WHERE version_id=%s) WHERE id=%s",
                                   (version_id, version_id))
                # Limpieza: se borran fragmentos de versiones retiradas.
                await conn.execute("DELETE FROM hz_chunk WHERE version_id IN (SELECT id FROM hz_index_version "
                                   "WHERE course_id=%s AND status='retired')", (course_id,))

    async def discard_version(self, version_id: int) -> None:
        async with self.pool.connection() as conn:
            async with conn.transaction():
                await conn.execute("DELETE FROM hz_chunk WHERE version_id=%s", (version_id,))
                await conn.execute("UPDATE hz_index_version SET status='failed' WHERE id=%s", (version_id,))

    async def log_interaction(self, course_id: int, question: str, answer) -> None:
        # Registro disociado (sin identificador de usuario) para la evaluación con RAGAS.
        async with self.pool.connection() as conn:
            await conn.execute(
                """INSERT INTO hz_interaction (course_id, question, answer, contexts, sources, max_score, status)
                   VALUES (%s,%s,%s,%s,%s,%s,%s)""",
                (course_id, question, answer.text, json.dumps(answer.contexts, ensure_ascii=False),
                 json.dumps([s.__dict__ for s in answer.sources], ensure_ascii=False),
                 answer.max_score, answer.status))

    async def course_status(self, course_id: int) -> dict:
        async with self.pool.connection() as conn:
            row = await (await conn.execute(
                "SELECT id, chunks, activated_at FROM hz_index_version WHERE course_id=%s AND status='active'",
                (course_id,))).fetchone()
        return {"course_id": course_id, "active_version": row[0] if row else None,
                "chunks": row[1] if row else 0, "activated_at": row[2].isoformat() if row and row[2] else None}
