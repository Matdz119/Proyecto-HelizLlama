"""Puertos de salida del dominio (arquitectura hexagonal).

El núcleo RAG solo conoce estas interfaces; Ollama, pgvector y los
extractores de documentos son adaptadores intercambiables.
"""
from typing import Protocol

from .models import Chunk, Resource, RetrievedChunk


class LLMPort(Protocol):
    async def generate(self, system: str, user: str) -> str: ...


class EmbeddingPort(Protocol):
    async def embed(self, texts: list[str]) -> list[list[float]]: ...


class VectorStorePort(Protocol):
    async def search(self, course_id: int, embedding: list[float], top_k: int) -> list[RetrievedChunk]: ...
    async def create_version(self, course_id: int) -> int: ...
    async def add_chunks(self, version_id: int, chunks: list[Chunk]) -> None: ...
    async def activate_version(self, course_id: int, version_id: int) -> None: ...
    async def discard_version(self, version_id: int) -> None: ...
    async def log_interaction(self, course_id: int, question: str, answer: "object") -> None: ...


class ContentSourcePort(Protocol):
    def extract_text(self, resource: Resource) -> str:
        """Devuelve el texto plano de un recurso (página, PDF, DOCX...)."""
        ...
