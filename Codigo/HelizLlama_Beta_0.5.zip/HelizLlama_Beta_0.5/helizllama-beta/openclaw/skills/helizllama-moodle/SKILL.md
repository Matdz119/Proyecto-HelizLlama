---
name: helizllama-moodle
description: Consulta, en modo de solo lectura, el contenido indexado de un curso de Moodle a través del orquestador HelizLlama. Úsala cuando pregunten por fechas, actividades o recursos de un curso concreto.
---

# HelizLlama – consulta de cursos de Moodle (solo lectura)

Esta skill es **opcional**: permite que un agente OpenClaw use HelizLlama como herramienta.
El asistente del curso en Moodle funciona sin ella.

## Reglas

- Solo se permite la operación de consulta `POST /v1/ask`. Nunca llames a `/v1/index` ni a la API de Moodle para escribir datos.
- Necesitas el identificador numérico del curso (`course_id`). Si no lo tienes, pídelo.
- No envíes datos personales de estudiantes en la pregunta.
- Muestra las fuentes que devuelve el orquestador.

## Cómo consultar

Variables de entorno requeridas: `HELIZLLAMA_URL` (por ejemplo `http://100.x.y.z:8000`) y `HELIZLLAMA_TOKEN`.

```bash
curl -s -X POST "$HELIZLLAMA_URL/v1/ask" \
  -H "Authorization: Bearer $HELIZLLAMA_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"course_id": 2, "question": "¿Cuándo se entrega la tarea 2?"}'
```

La respuesta incluye `status` (`ok`, `no_context`, `out_of_scope`), `answer` y `sources`.
Si `status` es `no_context`, informa que el curso no contiene esa información y no inventes una respuesta.
