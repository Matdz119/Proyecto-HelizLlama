"""Filtros puros del pipeline de indexación: limpieza y fragmentación."""
import re

_EMAIL = re.compile(r"[\w.+-]+@[\w-]+\.[\w.-]+")
_PHONE = re.compile(r"(?<!\d)(?:\+?593[\s-]?)?0?9\d{8}(?!\d)")
_CEDULA = re.compile(r"(?<!\d)\d{10}(?!\d)")
_SPACES = re.compile(r"[ \t]+")
_LINES = re.compile(r"\n{3,}")


def sanitize(text: str) -> str:
    """Elimina datos personales evidentes (correos, teléfonos, cédulas)."""
    text = _EMAIL.sub("[correo omitido]", text)
    text = _PHONE.sub("[teléfono omitido]", text)
    text = _CEDULA.sub("[dato omitido]", text)
    text = _SPACES.sub(" ", text)
    return _LINES.sub("\n\n", text).strip()


def chunk_text(text: str, size: int, overlap: int) -> list[str]:
    """Fragmenta por palabras con solapamiento, respetando párrafos cuando puede."""
    if size <= 0:
        raise ValueError("size debe ser positivo")
    overlap = max(0, min(overlap, size // 2))
    words = text.split()
    if not words:
        return []
    chunks, start = [], 0
    while start < len(words):
        end = min(start + size, len(words))
        chunks.append(" ".join(words[start:end]))
        if end == len(words):
            break
        start = end - overlap
    return chunks
