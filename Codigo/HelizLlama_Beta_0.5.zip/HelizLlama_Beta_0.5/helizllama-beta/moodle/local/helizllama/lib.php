<?php
/**
 * @package    local_helizllama
 * @copyright  2026 Jairo Ramírez, Brandon Acurio
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

/**
 * Añade los enlaces del asistente al menú del curso para docentes.
 */
function local_helizllama_extend_navigation_course(navigation_node $navigation, stdClass $course, context $context) {
    if (has_capability('local/helizllama:manageindex', $context)) {
        $navigation->add(get_string('managetitle', 'local_helizllama'),
            new moodle_url('/local/helizllama/manage.php', ['courseid' => $course->id]),
            navigation_node::TYPE_SETTING, null, 'local_helizllama_manage', new pix_icon('i/settings', ''));
    }
    if (has_capability('local/helizllama:viewreports', $context)) {
        $navigation->add(get_string('reporttitle', 'local_helizllama'),
            new moodle_url('/local/helizllama/report.php', ['courseid' => $course->id]),
            navigation_node::TYPE_SETTING, null, 'local_helizllama_report', new pix_icon('i/report', ''));
    }
}
