<?php
/**
 * @package    local_helizllama
 * @copyright  2026 Jairo Ramírez, Brandon Acurio
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_helizllama;

defined('MOODLE_INTERNAL') || die();

/**
 * Obtiene el contenido visible de un curso para indexarlo, en modo de solo lectura.
 * Nunca lee entregas, calificaciones, mensajes de foros ni datos de usuarios (RNF-07).
 */
class content_extractor {
    /** Tipos de archivo que el orquestador sabe extraer. */
    const MIMETYPES = ['application/pdf', 'text/plain', 'text/html', 'text/markdown',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];

    public static function course_resources(int $courseid): array {
        global $DB;
        $course = get_course($courseid);
        $modinfo = get_fast_modinfo($course, -1);
        $maxbytes = max(1, (int)get_config('local_helizllama', 'maxfilemb')) * 1024 * 1024;
        $resources = [];

        // Resumen del curso y de las secciones visibles.
        $summary = [format_string($course->fullname), strip_tags((string)$course->summary)];
        foreach ($modinfo->get_section_info_all() as $section) {
            if ($section->visible) {
                $summary[] = get_section_name($course, $section) . ': ' . strip_tags((string)$section->summary);
            }
        }
        $resources[] = self::res('course-' . $courseid, get_string('coursesummary', 'local_helizllama'), 'course',
            (new \moodle_url('/course/view.php', ['id' => $courseid]))->out(false), implode("\n", $summary));

        foreach ($modinfo->get_cms() as $cm) {
            if (!$cm->visible || $cm->deletioninprogress || !$cm->get_section_info()->visible) {
                continue;
            }
            $url = $cm->url ? $cm->url->out(false)
                : (new \moodle_url('/course/view.php', ['id' => $courseid]))->out(false);
            $name = format_string($cm->name);
            $id = 'cm-' . $cm->id;
            $intro = self::intro($cm);

            switch ($cm->modname) {
                case 'page':
                    $content = (string)$DB->get_field('page', 'content', ['id' => $cm->instance]);
                    $resources[] = self::res($id, $name, 'page', $url, $intro . "\n" . self::clean($content));
                    break;
                case 'assign':
                    $a = $DB->get_record('assign', ['id' => $cm->instance],
                        'allowsubmissionsfromdate, duedate, cutoffdate');
                    $lines = [$intro];
                    foreach (['allowsubmissionsfromdate' => 'assign_from', 'duedate' => 'assign_due',
                              'cutoffdate' => 'assign_cutoff'] as $field => $key) {
                        if (!empty($a->$field)) {
                            $lines[] = get_string($key, 'local_helizllama', userdate($a->$field));
                        }
                    }
                    $resources[] = self::res($id, $name, 'assign', $url, implode("\n", $lines));
                    break;
                case 'quiz':
                    $q = $DB->get_record('quiz', ['id' => $cm->instance], 'timeopen, timeclose, timelimit');
                    $lines = [$intro];
                    if (!empty($q->timeopen)) { $lines[] = get_string('quiz_open', 'local_helizllama', userdate($q->timeopen)); }
                    if (!empty($q->timeclose)) { $lines[] = get_string('quiz_close', 'local_helizllama', userdate($q->timeclose)); }
                    $resources[] = self::res($id, $name, 'quiz', $url, implode("\n", $lines));
                    break;
                case 'book':
                    $chapters = $DB->get_records('book_chapters', ['bookid' => $cm->instance, 'hidden' => 0],
                        'pagenum', 'title, content');
                    $text = $intro;
                    foreach ($chapters as $ch) {
                        $text .= "\n" . $ch->title . "\n" . self::clean($ch->content);
                    }
                    $resources[] = self::res($id, $name, 'book', $url, $text);
                    break;
                case 'url':
                    $ext = (string)$DB->get_field('url', 'externalurl', ['id' => $cm->instance]);
                    $resources[] = self::res($id, $name, 'url', $url, $intro . "\nEnlace: " . $ext);
                    break;
                case 'resource':
                case 'folder':
                    if (trim($intro) !== '') {
                        $resources[] = self::res($id, $name, $cm->modname, $url, $intro);
                    }
                    $fs = get_file_storage();
                    $files = $fs->get_area_files(\context_module::instance($cm->id)->id, 'mod_' . $cm->modname,
                        'content', false, 'sortorder, filepath, filename', false);
                    foreach ($files as $file) {
                        $mime = $file->get_mimetype();
                        if (!in_array($mime, self::MIMETYPES) || $file->get_filesize() > $maxbytes) {
                            continue;
                        }
                        $res = self::res($id . '-f' . $file->get_id(), $name . ': ' . $file->get_filename(),
                            $cm->modname, $url, '');
                        $res['filename'] = $file->get_filename();
                        $res['mimetype'] = $mime;
                        $res['content_b64'] = base64_encode($file->get_content());
                        $resources[] = $res;
                    }
                    break;
                default:
                    // Foros, wikis, etc.: solo nombre y descripción, nunca publicaciones de usuarios.
                    $resources[] = self::res($id, $name, $cm->modname, $url, $intro);
            }
        }
        return array_values(array_filter($resources, function($r) {
            return trim($r['text']) !== '' || $r['content_b64'] !== '';
        }));
    }

    private static function intro(\cm_info $cm): string {
        global $DB;
        $dbman = $DB->get_manager();
        if (!$dbman->field_exists($cm->modname, 'intro')) {
            return '';
        }
        return self::clean((string)$DB->get_field($cm->modname, 'intro', ['id' => $cm->instance]));
    }

    private static function clean(string $html): string {
        $html = str_replace('@@PLUGINFILE@@', '', $html);
        return trim(html_entity_decode(strip_tags(preg_replace('/<(br|\/p|\/li|\/h\d)[^>]*>/i', "\n", $html)),
            ENT_QUOTES, 'UTF-8'));
    }

    private static function res(string $id, string $name, string $type, string $url, string $text): array {
        return ['resource_id' => $id, 'name' => $name, 'type' => $type, 'url' => $url, 'text' => $text,
            'filename' => '', 'mimetype' => '', 'content_b64' => ''];
    }
}
