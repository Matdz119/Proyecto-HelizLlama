<?php
/**
 * Strings for block_helizllama (es).
 *
 * @package    block_helizllama
 * @copyright  2026 Jairo Ramírez, Brandon Acurio
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['assistant'] = 'HelizLlama';
$string['disclaimer'] = 'Las respuestas se basan solo en este curso. Verifica siempre las fechas importantes en la propia actividad.';
$string['empty'] = 'Aún no hay preguntas.';
$string['helizllama:addinstance'] = 'Agregar el bloque del asistente HelizLlama';
$string['intro'] = 'Pregunta sobre las actividades, fechas y recursos de este curso.';
$string['manageindex'] = 'Estado del índice del curso';
$string['placeholder'] = 'Escribe tu pregunta…';
$string['pluginname'] = 'Asistente HelizLlama';
$string['privacy:metadata'] = 'El bloque HelizLlama no almacena datos personales; las preguntas las gestiona local_helizllama.';
$string['send'] = 'Enviar';
$string['sources'] = 'Fuentes:';
$string['thanks'] = 'Gracias por tu valoración.';
$string['thinking'] = 'Buscando en los recursos del curso…';
$string['viewreport'] = 'Seguimiento de uso';
$string['wasuseful'] = '¿Te fue útil esta respuesta?';
$string['you'] = 'Tú';
