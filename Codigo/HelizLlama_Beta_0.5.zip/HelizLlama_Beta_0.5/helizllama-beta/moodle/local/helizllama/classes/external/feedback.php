<?php
/**
 * @package    local_helizllama
 * @copyright  2026 Jairo Ramírez, Brandon Acurio
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_helizllama\external;

use core_external\external_api;
use core_external\external_function_parameters;
use core_external\external_single_structure;
use core_external\external_value;

defined('MOODLE_INTERNAL') || die();

/**
 * Registra la valoración Útil / No útil de una respuesta (HU-08).
 */
class feedback extends external_api {
    public static function execute_parameters(): external_function_parameters {
        return new external_function_parameters([
            'logid' => new external_value(PARAM_INT, 'ID del registro'),
            'useful' => new external_value(PARAM_BOOL, 'true si la respuesta fue útil'),
        ]);
    }

    public static function execute(int $logid, bool $useful): array {
        global $DB, $SESSION;
        $params = self::validate_parameters(self::execute_parameters(), ['logid' => $logid, 'useful' => $useful]);
        $log = $DB->get_record('local_helizllama_log', ['id' => $params['logid']], 'id, courseid', MUST_EXIST);
        $context = \context_course::instance($log->courseid);
        self::validate_context($context);
        require_capability('local/helizllama:use', $context);
        if (!in_array($log->id, $SESSION->local_helizllama_logs ?? [])) {
            throw new \moodle_exception('cannotrate', 'local_helizllama');
        }
        $DB->set_field('local_helizllama_log', 'feedback', $params['useful'] ? 1 : 0, ['id' => $log->id]);
        return ['saved' => true];
    }

    public static function execute_returns(): external_single_structure {
        return new external_single_structure(['saved' => new external_value(PARAM_BOOL, 'Guardado')]);
    }
}
