// This file is part of Moodle - https://moodle.org/
// GNU GPL v3 or later.

/**
 * Comportamiento del panel de chat de HelizLlama.
 * Todo el texto del modelo se inserta con textContent para evitar inyección de HTML.
 *
 * @module     block_helizllama/chat
 * @copyright  2026 Jairo Ramírez, Brandon Acurio
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
define(['core/ajax', 'core/str', 'core/notification'], function(Ajax, Str, Notification) {
    var strings = {};

    var el = function(tag, cls, text) {
        var node = document.createElement(tag);
        if (cls) {
            node.className = cls;
        }
        if (text !== undefined) {
            node.textContent = text;
        }
        return node;
    };

    var scroll = function(box) {
        box.scrollTop = box.scrollHeight;
    };

    var addFeedback = function(container, logid) {
        var wrap = el('div', 'mt-1 small');
        wrap.appendChild(el('span', 'text-muted mr-2 me-2', strings.wasuseful));
        [[true, strings.useful], [false, strings.notuseful]].forEach(function(opt) {
            var btn = el('button', 'btn btn-link btn-sm p-0 mr-2 me-2', opt[1]);
            btn.type = 'button';
            btn.addEventListener('click', function() {
                Ajax.call([{methodname: 'local_helizllama_feedback', args: {logid: logid, useful: opt[0]}}])[0]
                    .then(function() {
                        wrap.textContent = strings.thanks;
                        return null;
                    }).catch(Notification.exception);
            });
            wrap.appendChild(btn);
        });
        container.appendChild(wrap);
    };

    var renderAnswer = function(box, data) {
        var msg = el('div', 'helizllama-answer bg-light rounded p-2 mb-2');
        msg.appendChild(el('div', 'font-weight-bold fw-bold small', strings.assistant));
        var body = el('div', '');
        body.style.whiteSpace = 'pre-wrap';
        body.textContent = data.answer;
        msg.appendChild(body);
        if (data.sources && data.sources.length) {
            msg.appendChild(el('div', 'small text-muted mt-1', strings.sources));
            var list = el('ul', 'small mb-0 pl-3 ps-3');
            data.sources.forEach(function(src, i) {
                var li = el('li', '');
                if (src.url && /^https?:\/\//i.test(src.url)) {
                    var a = el('a', '', '[' + (i + 1) + '] ' + src.name);
                    a.href = src.url;
                    li.appendChild(a);
                } else {
                    li.textContent = '[' + (i + 1) + '] ' + src.name;
                }
                list.appendChild(li);
            });
            msg.appendChild(list);
        }
        if (data.logid && data.status !== 'error') {
            addFeedback(msg, data.logid);
        }
        box.appendChild(msg);
        scroll(box);
    };

    var init = function(uniqid, courseid) {
        var root = document.getElementById(uniqid);
        if (!root) {
            return;
        }
        var box = root.querySelector('[data-region="messages"]');
        var form = root.querySelector('[data-region="form"]');
        var input = root.querySelector('[data-region="question"]');
        var send = root.querySelector('[data-region="send"]');

        Str.get_strings([
            {key: 'you', component: 'block_helizllama'},
            {key: 'assistant', component: 'block_helizllama'},
            {key: 'thinking', component: 'block_helizllama'},
            {key: 'sources', component: 'block_helizllama'},
            {key: 'wasuseful', component: 'block_helizllama'},
            {key: 'useful', component: 'local_helizllama'},
            {key: 'notuseful', component: 'local_helizllama'},
            {key: 'thanks', component: 'block_helizllama'},
            {key: 'unavailable', component: 'local_helizllama'}
        ]).then(function(s) {
            ['you', 'assistant', 'thinking', 'sources', 'wasuseful', 'useful', 'notuseful', 'thanks', 'unavailable']
                .forEach(function(k, i) {
                    strings[k] = s[i];
                });
            return null;
        }).catch(Notification.exception);

        input.addEventListener('keydown', function(e) {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                form.requestSubmit ? form.requestSubmit() : form.dispatchEvent(new Event('submit'));
            }
        });

        form.addEventListener('submit', function(e) {
            e.preventDefault();
            var question = input.value.trim();
            if (!question || send.disabled) {
                return;
            }
            var empty = root.querySelector('[data-region="empty"]');
            if (empty) {
                empty.remove();
            }
            var mine = el('div', 'helizllama-question text-right text-end mb-2');
            mine.appendChild(el('div', 'small text-muted', strings.you));
            mine.appendChild(el('div', '', question));
            box.appendChild(mine);
            var waiting = el('div', 'text-muted small mb-2', strings.thinking);
            box.appendChild(waiting);
            scroll(box);
            input.value = '';
            send.disabled = true;

            Ajax.call([{methodname: 'local_helizllama_ask', args: {courseid: courseid, question: question}}])[0]
                .then(function(data) {
                    waiting.remove();
                    renderAnswer(box, data);
                    return null;
                })
                .catch(function() {
                    waiting.remove();
                    renderAnswer(box, {answer: strings.unavailable, sources: [], status: 'error'});
                })
                .then(function() {
                    send.disabled = false;
                    input.focus();
                    return null;
                });
        });
    };

    return {init: init};
});
