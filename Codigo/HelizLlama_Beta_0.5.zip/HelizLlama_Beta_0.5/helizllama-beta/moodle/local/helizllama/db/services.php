<?php
/**
 * Servicios externos (AJAX) de local_helizllama.
 *
 * @package    local_helizllama
 * @copyright  2026 Jairo Ramírez, Brandon Acurio
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$functions = [
    'local_helizllama_ask' => [
        'classname'    => \local_helizllama\external\ask::class,
        'description'  => 'Envía una pregunta del curso al orquestador RAG y devuelve la respuesta con fuentes.',
        'type'         => 'read',
        'ajax'         => true,
        'capabilities' => 'local/helizllama:use',
    ],
    'local_helizllama_feedback' => [
        'classname'    => \local_helizllama\external\feedback::class,
        'description'  => 'Registra la valoración Útil / No útil de una respuesta (HU-08).',
        'type'         => 'write',
        'ajax'         => true,
        'capabilities' => 'local/helizllama:use',
    ],
];
