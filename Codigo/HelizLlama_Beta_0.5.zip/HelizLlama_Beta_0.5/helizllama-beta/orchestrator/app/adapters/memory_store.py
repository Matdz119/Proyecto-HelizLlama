"""VectorStorePort en memoria: para pruebas del dominio sin base de datos."""
import math

from ..domain.models import Chunk, RetrievedChunk


def _cos(a, b):
    na, nb = math.sqrt(sum(x * x for x in a)), math.sqrt(sum(y * y for y in b))
    return sum(x * y for x, y in zip(a, b)) / (na * nb) if na and nb else 0.0


class MemoryStore:
    def __init__(self):
        self.versions: dict[int, dict] = {}
        self.chunks: dict[int, list[Chunk]] = {}
        self.interactions: list[tuple] = []
        self._next = 1

    async def search(self, course_id, embedding, top_k):
        active = [v for v, meta in self.versions.items() if meta["course"] == course_id and meta["status"] == "active"]
        cands = [c for v in active for c in self.chunks.get(v, [])]
        scored = sorted((RetrievedChunk(c, _cos(embedding, c.embedding)) for c in cands),
                        key=lambda r: r.score, reverse=True)
        return scored[:top_k]

    async def create_version(self, course_id):
        vid = self._next; self._next += 1
        self.versions[vid] = {"course": course_id, "status": "building"}
        self.chunks[vid] = []
        return vid

    async def add_chunks(self, version_id, chunks):
        self.chunks[version_id].extend(chunks)

    async def activate_version(self, course_id, version_id):
        for meta in self.versions.values():
            if meta["course"] == course_id and meta["status"] == "active":
                meta["status"] = "retired"
        self.versions[version_id]["status"] = "active"

    async def discard_version(self, version_id):
        self.versions[version_id]["status"] = "failed"
        self.chunks[version_id] = []

    async def log_interaction(self, course_id, question, answer):
        self.interactions.append((course_id, question, answer.status))
