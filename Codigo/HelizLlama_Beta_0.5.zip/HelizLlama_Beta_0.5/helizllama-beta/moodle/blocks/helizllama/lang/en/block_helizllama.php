<?php
/**
 * Strings for block_helizllama (en).
 *
 * @package    block_helizllama
 * @copyright  2026 Jairo Ramírez, Brandon Acurio
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['assistant'] = 'HelizLlama';
$string['disclaimer'] = 'Answers are based only on this course. Always verify important dates in the activity itself.';
$string['empty'] = 'No questions yet.';
$string['helizllama:addinstance'] = 'Add a HelizLlama assistant block';
$string['intro'] = 'Ask about this course\'s activities, dates and resources.';
$string['manageindex'] = 'Course index status';
$string['placeholder'] = 'Type your question…';
$string['pluginname'] = 'HelizLlama assistant';
$string['privacy:metadata'] = 'The HelizLlama block does not store personal data; questions are handled by local_helizllama.';
$string['send'] = 'Send';
$string['sources'] = 'Sources:';
$string['thanks'] = 'Thanks for your feedback.';
$string['thinking'] = 'Searching the course resources…';
$string['viewreport'] = 'Usage report';
$string['wasuseful'] = 'Was this answer helpful?';
$string['you'] = 'You';
