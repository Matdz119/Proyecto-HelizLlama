<?php
/**
 * Estado del índice del curso e indexación manual (HU-02, RF-13).
 *
 * @package    local_helizllama
 * @copyright  2026 Jairo Ramírez, Brandon Acurio
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require(__DIR__ . '/../../config.php');

use local_helizllama\index_manager;

$courseid = required_param('courseid', PARAM_INT);
$action = optional_param('action', '', PARAM_ALPHA);
$course = get_course($courseid);
require_login($course);
$context = context_course::instance($courseid);
require_capability('local/helizllama:manageindex', $context);

$url = new moodle_url('/local/helizllama/manage.php', ['courseid' => $courseid]);
$PAGE->set_url($url);
$PAGE->set_context($context);
$PAGE->set_pagelayout('incourse');
$PAGE->set_title(get_string('managetitle', 'local_helizllama'));
$PAGE->set_heading(format_string($course->fullname));

if ($action === 'index' && confirm_sesskey()) {
    index_manager::queue($courseid);
    redirect($url, get_string('indexqueued', 'local_helizllama'), null, \core\output\notification::NOTIFY_SUCCESS);
}

$rec = index_manager::get($courseid);
echo $OUTPUT->header();
echo $OUTPUT->heading(get_string('managetitle', 'local_helizllama'));

if (!index_manager::assistant_enabled($courseid)) {
    echo $OUTPUT->notification(get_string('assistantnotenabled', 'local_helizllama'), 'warning');
}

$table = new html_table();
$table->attributes['class'] = 'generaltable';
$table->data = [
    [get_string('status', 'local_helizllama'), get_string('status_' . $rec->status, 'local_helizllama')],
    [get_string('resources', 'local_helizllama'), $rec->resources],
    [get_string('chunks', 'local_helizllama'), $rec->chunks],
    [get_string('lastindexed', 'local_helizllama'),
        $rec->lastindexed ? userdate($rec->lastindexed) : get_string('never', 'local_helizllama')],
    [get_string('pendingchanges', 'local_helizllama'), $rec->dirty ? get_string('yes') : get_string('no')],
    [get_string('message', 'local_helizllama'), s((string)$rec->message)],
];
echo html_writer::table($table);
echo $OUTPUT->single_button(new moodle_url($url, ['action' => 'index']), get_string('indexnow', 'local_helizllama'), 'post',
    ['type' => single_button::BUTTON_PRIMARY]);
echo html_writer::tag('p', get_string('indexhelp', 'local_helizllama'), ['class' => 'mt-3 text-muted']);
echo $OUTPUT->footer();
