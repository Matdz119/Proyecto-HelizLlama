<?php
/**
 * Observadores de eventos: reindexación automática (HU-03, HT-07).
 *
 * @package    local_helizllama
 * @copyright  2026 Jairo Ramírez, Brandon Acurio
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$observers = [
    ['eventname' => '\core\event\course_module_created', 'callback' => '\local_helizllama\observer::content_changed'],
    ['eventname' => '\core\event\course_module_updated', 'callback' => '\local_helizllama\observer::content_changed'],
    ['eventname' => '\core\event\course_module_deleted', 'callback' => '\local_helizllama\observer::content_changed'],
    ['eventname' => '\core\event\course_section_updated', 'callback' => '\local_helizllama\observer::content_changed'],
    ['eventname' => '\core\event\course_updated', 'callback' => '\local_helizllama\observer::content_changed'],
];
