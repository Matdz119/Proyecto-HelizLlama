# Inicia la Consola HelizLlama (prueba del núcleo RAG sin Moodle ni base de datos).
# Uso:  .\iniciar_consola.ps1                      -> Ollama local (localhost:11434)
#       .\iniciar_consola.ps1 -OllamaUrl http://100.x.y.z:11434   -> Ollama por Tailscale
param([string]$OllamaUrl = "http://localhost:11434", [int]$Puerto = 8090)

$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

if (-not (Test-Path ".venv\Scripts\python.exe")) {
    Write-Host "Creando entorno virtual .venv ..." -ForegroundColor Cyan
    python -m venv .venv
}
& .\.venv\Scripts\python.exe -m pip install --quiet --upgrade pip
& .\.venv\Scripts\python.exe -m pip install --quiet -r devtools\requirements.txt

$env:HZ_OLLAMA_URL = $OllamaUrl
Write-Host ""
Write-Host "Ollama: $OllamaUrl" -ForegroundColor Green
Write-Host "Abre http://localhost:$Puerto en el navegador (Ctrl + C para detener)" -ForegroundColor Green
& .\.venv\Scripts\python.exe -m uvicorn devtools.consola:app --port $Puerto
