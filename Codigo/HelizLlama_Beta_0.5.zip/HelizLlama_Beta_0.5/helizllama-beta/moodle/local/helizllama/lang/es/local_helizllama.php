<?php
/**
 * Strings for local_helizllama (es).
 *
 * @package    local_helizllama
 * @copyright  2026 Jairo Ramírez, Brandon Acurio
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['answered'] = 'Respondidas';
$string['apitoken'] = 'Token de la API';
$string['apitoken_desc'] = 'Debe coincidir con HZ_API_TOKEN del archivo .env del orquestador.';
$string['assign_cutoff'] = 'Fecha límite final: {$a}';
$string['assign_due'] = 'Fecha de entrega: {$a}';
$string['assign_from'] = 'Entregas habilitadas desde: {$a}';
$string['assistantnotenabled'] = 'Agrega el bloque HelizLlama a este curso para activar el asistente y la reindexación automática.';
$string['avglatency'] = 'Tiempo promedio';
$string['cannotrate'] = 'Solo puedes valorar las respuestas a tus propias preguntas en esta sesión.';
$string['checkhealth'] = 'Verificar el estado del orquestador';
$string['chunks'] = 'Fragmentos';
$string['connection'] = 'Conexión con el orquestador';
$string['connection_desc'] = 'El plugin nunca llama directamente a Ollama: solo se comunica con el orquestador RAG a través de la red privada (Tailscale).';
$string['coursesummary'] = 'Información del curso';
$string['errors'] = 'Errores';
$string['feedback'] = 'Valoración';
$string['healthok'] = 'El orquestador respondió correctamente.';
$string['healthtitle'] = 'Estado de los servicios de HelizLlama';
$string['helizllama:manageindex'] = 'Gestionar el índice de HelizLlama del curso';
$string['helizllama:use'] = 'Usar el asistente HelizLlama';
$string['helizllama:viewreports'] = 'Ver los informes de uso de HelizLlama';
$string['indexhelp'] = 'La indexación se ejecuta en segundo plano y crea una nueva versión del índice; si falla, la versión anterior sigue activa.';
$string['indexnow'] = 'Indexar el contenido del curso ahora';
$string['indexqueued'] = 'La indexación quedó en cola. Se ejecutará en la próxima ejecución del cron.';
$string['lastindexed'] = 'Última indexación correcta';
$string['latency'] = 'Tiempo de respuesta';
$string['managetitle'] = 'HelizLlama: índice del curso';
$string['maxfilemb'] = 'Tamaño máximo de archivo (MB)';
$string['maxfilemb_desc'] = 'Los archivos PDF o DOCX más grandes no se indexan.';
$string['message'] = 'Mensaje';
$string['never'] = 'Nunca';
$string['nocontext'] = 'Sin información en el curso';
$string['notconfigured'] = 'La URL o el token del orquestador no están configurados.';
$string['notuseful'] = 'No útil';
$string['orchestratorerror'] = 'El orquestador devolvió un error.';
$string['orchestratorunreachable'] = 'No se pudo contactar al orquestador.';
$string['orchestratorurl'] = 'URL del orquestador';
$string['orchestratorurl_desc'] = 'URL base del orquestador FastAPI, por ejemplo http://100.x.y.z:8000 (IP de Tailscale).';
$string['outofscope'] = 'Fuera de alcance';
$string['pendingchanges'] = 'Cambios pendientes de indexar';
$string['pluginname'] = 'Asistente HelizLlama';
$string['privacy:metadata:orchestrator'] = 'El texto de la pregunta y el identificador del curso se envían al orquestador RAG de HelizLlama (servidor local, sin servicios en la nube) para generar la respuesta. No se envía ningún identificador de usuario.';
$string['privacy:metadata:orchestrator:courseid'] = 'El identificador del curso';
$string['privacy:metadata:orchestrator:question'] = 'La pregunta realizada';
$string['question'] = 'Pregunta';
$string['quiz_close'] = 'Se cierra: {$a}';
$string['quiz_open'] = 'Se abre: {$a}';
$string['reportprivacy'] = 'Las preguntas se guardan sin ningún dato que identifique al estudiante.';
$string['reporttitle'] = 'HelizLlama: seguimiento de uso';
$string['resources'] = 'Recursos indexados';
$string['retrieval'] = 'Parámetros de recuperación';
$string['skipped'] = 'Recursos omitidos: {$a}';
$string['status'] = 'Estado';
$string['status_error'] = 'Error (sigue activo el índice anterior)';
$string['status_ok'] = 'Actualizado';
$string['status_pending'] = 'Sin indexar';
$string['status_queued'] = 'En cola';
$string['status_running'] = 'Indexando';
$string['taskdailysync'] = 'Reconciliación diaria del índice de HelizLlama';
$string['threshold'] = 'Umbral de similitud';
$string['threshold_desc'] = 'Valor entre 0 y 1. Por debajo de él, el asistente declara que la información no está en el curso y no invoca al modelo.';
$string['threshold_invalid'] = 'El umbral debe ser un número entre 0 y 1.';
$string['timeout'] = 'Tiempo máximo (segundos)';
$string['timeout_desc'] = 'Espera máxima por una respuesta antes de mostrar un mensaje de error.';
$string['topk'] = 'Fragmentos a recuperar (top-k)';
$string['topk_desc'] = 'Número de fragmentos del curso que se envían como contexto al modelo.';
$string['total'] = 'Consultas';
$string['unavailable'] = 'El asistente no está disponible en este momento. Intenta de nuevo en unos minutos; el curso funciona con normalidad.';
$string['useful'] = 'Útil';
