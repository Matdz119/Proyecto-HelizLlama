"""Entidades del dominio RAG. No dependen de ninguna tecnología externa."""
from dataclasses import dataclass, field


@dataclass(frozen=True)
class Resource:
    """Recurso de un curso enviado por Moodle para indexar."""
    resource_id: str
    name: str
    type: str
    url: str = ""
    text: str = ""
    filename: str = ""
    mimetype: str = ""
    content_b64: str = ""


@dataclass(frozen=True)
class Chunk:
    course_id: int
    resource_id: str
    resource_name: str
    resource_url: str
    resource_type: str
    chunk_index: int
    content: str
    embedding: list[float] = field(default_factory=list)


@dataclass(frozen=True)
class RetrievedChunk:
    chunk: Chunk
    score: float  # similitud coseno (0 a 1)


@dataclass(frozen=True)
class Source:
    name: str
    url: str


@dataclass
class Answer:
    status: str               # ok | no_context | out_of_scope | rejected
    text: str
    sources: list[Source] = field(default_factory=list)
    max_score: float = 0.0
    contexts: list[str] = field(default_factory=list)


@dataclass
class IndexReport:
    course_id: int
    version_id: int | None
    resources_received: int
    resources_indexed: int
    resources_skipped: list[str]
    chunks: int
    status: str               # ok | failed
    message: str = ""
