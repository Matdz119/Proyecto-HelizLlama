"""Casos de uso del núcleo RAG: consultar (AskService) e indexar (IndexService)."""
import re
import logging

from .models import Answer, Chunk, IndexReport, Resource, Source
from .ports import ContentSourcePort, EmbeddingPort, LLMPort, VectorStorePort
from .prompt import SYSTEM_PROMPT, build_user_prompt
from .text import chunk_text, sanitize

log = logging.getLogger("helizllama.domain")

NO_CONTEXT_MSG = ("No encontré información sobre eso en los recursos de este curso. "
                  "Te sugiero revisar la sección correspondiente del aula virtual o consultar a tu docente.")
OUT_OF_SCOPE_MSG = ("No puedo responder consultas sobre calificaciones ni datos personales. "
                    "Para ese tipo de información consulta directamente en Moodle o con tu docente.")

_OUT_OF_SCOPE = re.compile(
    r"\b(mi[s]? (nota|calificaci[oó]n|promedio)|cu[aá]nto (saqu[eé]|tengo)|contrase[ñn]a|password|"
    r"c[eé]dula|tel[eé]fono de|correo de|direcci[oó]n de)\b", re.IGNORECASE)


class AskService:
    def __init__(self, llm: LLMPort, embedder: EmbeddingPort, store: VectorStorePort,
                 default_threshold: float, default_top_k: int, max_question_chars: int):
        self.llm, self.embedder, self.store = llm, embedder, store
        self.default_threshold = default_threshold
        self.default_top_k = default_top_k
        self.max_question_chars = max_question_chars

    async def ask(self, course_id: int, question: str,
                  threshold: float | None = None, top_k: int | None = None) -> Answer:
        question = (question or "").strip()
        threshold = self.default_threshold if threshold is None else threshold
        top_k = self.default_top_k if top_k is None else top_k

        # 1. Cadena de validación: sin invocar al modelo.
        if not question or len(question) > self.max_question_chars:
            return Answer(status="rejected", text=f"La pregunta debe tener entre 1 y {self.max_question_chars} caracteres.")
        if _OUT_OF_SCOPE.search(question):
            answer = Answer(status="out_of_scope", text=OUT_OF_SCOPE_MSG)
            await self.store.log_interaction(course_id, question, answer)
            return answer

        # 2. Recuperación filtrada por curso.
        [vector] = await self.embedder.embed([question])
        hits = await self.store.search(course_id, vector, top_k)
        relevant = [h for h in hits if h.score >= threshold]
        max_score = max((h.score for h in hits), default=0.0)

        # 3. Umbral: sin contexto relevante no se llama al LLM (HU-05).
        if not relevant:
            answer = Answer(status="no_context", text=NO_CONTEXT_MSG, max_score=max_score)
            await self.store.log_interaction(course_id, question, answer)
            return answer

        # 4. Generación con citas.
        text = await self.llm.generate(SYSTEM_PROMPT, build_user_prompt(question, relevant))
        sources, seen = [], set()
        for h in relevant:
            key = (h.chunk.resource_name, h.chunk.resource_url)
            if key not in seen:
                seen.add(key)
                sources.append(Source(name=h.chunk.resource_name, url=h.chunk.resource_url))
        answer = Answer(status="ok", text=text.strip(), sources=sources, max_score=max_score,
                        contexts=[h.chunk.content for h in relevant])
        await self.store.log_interaction(course_id, question, answer)  # conservado para RAGAS (RNF-10)
        return answer


class IndexService:
    """Pipeline de tuberías y filtros con índice en sombra (HT-10)."""

    def __init__(self, embedder: EmbeddingPort, store: VectorStorePort, source: ContentSourcePort,
                 chunk_size: int, chunk_overlap: int, embed_batch: int = 16):
        self.embedder, self.store, self.source = embedder, store, source
        self.chunk_size, self.chunk_overlap, self.embed_batch = chunk_size, chunk_overlap, embed_batch

    async def index_course(self, course_id: int, resources: list[Resource]) -> IndexReport:
        version_id = await self.store.create_version(course_id)   # índice en sombra
        skipped, indexed, total_chunks = [], 0, 0
        try:
            for res in resources:
                try:
                    raw = self.source.extract_text(res)
                except Exception as exc:  # recurso ilegible: se omite, no detiene el curso
                    log.warning("No se pudo extraer %s: %s", res.resource_id, exc)
                    skipped.append(res.name)
                    continue
                pieces = chunk_text(sanitize(raw), self.chunk_size, self.chunk_overlap)
                if not pieces:
                    skipped.append(res.name)
                    continue
                for start in range(0, len(pieces), self.embed_batch):
                    batch = pieces[start:start + self.embed_batch]
                    vectors = await self.embedder.embed(batch)
                    chunks = [Chunk(course_id, res.resource_id, res.name, res.url, res.type,
                                    start + i, text, vec)
                              for i, (text, vec) in enumerate(zip(batch, vectors))]
                    await self.store.add_chunks(version_id, chunks)
                    total_chunks += len(chunks)
                indexed += 1
            await self.store.activate_version(course_id, version_id)  # activación atómica
            return IndexReport(course_id, version_id, len(resources), indexed, skipped, total_chunks, "ok")
        except Exception as exc:
            await self.store.discard_version(version_id)               # rollback: sigue la versión anterior
            log.exception("Indexación fallida del curso %s", course_id)
            return IndexReport(course_id, None, len(resources), indexed, skipped, total_chunks, "failed", str(exc))
