from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_prefix="HZ_")

    api_token: str = "cambia-este-token"
    ollama_url: str = "http://host.docker.internal:11434"
    llm_model: str = "mistral"
    embed_model: str = "bge-m3"
    embed_dim: int = 1024
    llm_temperature: float = 0.2
    llm_num_ctx: int = 8192
    llm_timeout_s: float = 120.0
    database_url: str = "postgresql://helizllama:helizllama@db:5432/helizllama"
    similarity_threshold: float = 0.45
    top_k: int = 5
    chunk_size_words: int = 220
    chunk_overlap_words: int = 40
    max_question_chars: int = 1000
    max_concurrent_inferences: int = 1
    queue_wait_s: float = 60.0
    max_file_mb: int = 15


settings = Settings()
