<?php
// This file is part of Moodle - https://moodle.org/
// Moodle is free software: you can redistribute it and/or modify it under the terms of the
// GNU General Public License as published by the Free Software Foundation, either version 3 of the License.

/**
 * HelizLlama - lógica del asistente conversacional RAG.
 *
 * @package    local_helizllama
 * @copyright  2026 Jairo Ramírez, Brandon Acurio
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$plugin->component = 'local_helizllama';
$plugin->version   = 2026102000;
$plugin->requires  = 2024100700; // Moodle 4.5 o superior (probado en 5.3).
$plugin->maturity  = MATURITY_BETA;
$plugin->release   = '0.5.0-beta';
