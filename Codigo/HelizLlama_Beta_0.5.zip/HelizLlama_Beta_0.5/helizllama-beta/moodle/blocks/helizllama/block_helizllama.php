<?php
/**
 * Bloque block_helizllama: panel de chat del asistente dentro del curso (HU-01, HU-08).
 *
 * @package    block_helizllama
 * @copyright  2026 Jairo Ramírez, Brandon Acurio
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

class block_helizllama extends block_base {
    public function init() {
        $this->title = get_string('pluginname', 'block_helizllama');
    }

    public function applicable_formats() {
        return ['course-view' => true, 'site' => false, 'my' => false, 'mod' => false];
    }

    public function instance_allow_multiple() {
        return false;
    }

    public function has_config() {
        return false;
    }

    public function get_content() {
        global $OUTPUT;
        if ($this->content !== null) {
            return $this->content;
        }
        $this->content = (object)['text' => '', 'footer' => ''];
        $course = $this->page->course;
        $context = context_course::instance($course->id);
        if ($course->id == SITEID || !has_capability('local/helizllama:use', $context)) {
            return $this->content;
        }

        $uniqid = html_writer::random_id('helizllama');
        $data = [
            'uniqid' => $uniqid,
            'canmanage' => has_capability('local/helizllama:manageindex', $context),
            'canreport' => has_capability('local/helizllama:viewreports', $context),
            'manageurl' => (new moodle_url('/local/helizllama/manage.php', ['courseid' => $course->id]))->out(false),
            'reporturl' => (new moodle_url('/local/helizllama/report.php', ['courseid' => $course->id]))->out(false),
        ];
        $this->content->text = $OUTPUT->render_from_template('block_helizllama/chat', $data);
        $this->page->requires->js_call_amd('block_helizllama/chat', 'init', [$uniqid, (int)$course->id]);
        return $this->content;
    }
}
