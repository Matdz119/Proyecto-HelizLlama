<?php
/**
 * Cliente HTTP hacia el orquestador RAG con token y tiempo máximo (RF-09, RNF-08).
 *
 * @package    local_helizllama
 * @copyright  2026 Jairo Ramírez, Brandon Acurio
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_helizllama;

defined('MOODLE_INTERNAL') || die();

global $CFG;
require_once($CFG->libdir . '/filelib.php');

class client {
    /** @var string */
    private $baseurl;
    /** @var string */
    private $token;

    public function __construct() {
        $this->baseurl = rtrim((string)get_config('local_helizllama', 'orchestratorurl'), '/');
        $this->token = (string)get_config('local_helizllama', 'apitoken');
    }

    /**
     * Realiza una petición JSON y devuelve el cuerpo decodificado.
     *
     * @throws \moodle_exception si hay error de red, tiempo agotado o respuesta no válida.
     */
    public function request(string $method, string $path, ?array $payload = null, ?int $timeout = null): array {
        if ($this->baseurl === '' || $this->token === '') {
            throw new \moodle_exception('notconfigured', 'local_helizllama');
        }
        $timeout = $timeout ?? (int)get_config('local_helizllama', 'timeout') ?: 90;
        // ignoresecurity: el orquestador vive en una IP privada de Tailscale (100.x.y.z), que la lista
        // de hosts bloqueados de Moodle impediría alcanzar. Solo se usa con la URL configurada por el admin.
        $curl = new \curl(['ignoresecurity' => true]);
        $curl->setHeader(['Content-Type: application/json', 'Accept: application/json',
            'Authorization: Bearer ' . $this->token]);
        $options = ['CURLOPT_TIMEOUT' => $timeout, 'CURLOPT_CONNECTTIMEOUT' => 10];
        $url = $this->baseurl . $path;
        $body = $method === 'GET' ? $curl->get($url, [], $options)
                                  : $curl->post($url, json_encode($payload, JSON_UNESCAPED_UNICODE), $options);
        $info = $curl->get_info();
        $code = (int)($info['http_code'] ?? 0);
        if ($curl->get_errno()) {
            throw new \moodle_exception('orchestratorunreachable', 'local_helizllama', '', null, $curl->error);
        }
        $data = json_decode((string)$body, true);
        if ($code >= 400 || !is_array($data)) {
            $detail = is_array($data) && isset($data['detail']) ? (is_string($data['detail']) ? $data['detail'] : json_encode($data['detail'])) : "HTTP $code";
            throw new \moodle_exception('orchestratorerror', 'local_helizllama', '', null, $detail);
        }
        return $data;
    }
}
