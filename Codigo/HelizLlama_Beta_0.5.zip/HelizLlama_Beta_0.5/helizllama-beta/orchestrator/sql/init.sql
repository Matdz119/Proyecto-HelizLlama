CREATE EXTENSION IF NOT EXISTS vector;

CREATE TABLE IF NOT EXISTS hz_index_version (
    id            SERIAL PRIMARY KEY,
    course_id     INTEGER NOT NULL,
    status        TEXT NOT NULL CHECK (status IN ('building','active','retired','failed')),
    chunks        INTEGER DEFAULT 0,
    created_at    TIMESTAMPTZ DEFAULT now(),
    activated_at  TIMESTAMPTZ
);
-- Solo una versión activa por curso.
CREATE UNIQUE INDEX IF NOT EXISTS hz_one_active ON hz_index_version (course_id) WHERE status = 'active';

CREATE TABLE IF NOT EXISTS hz_chunk (
    id             BIGSERIAL PRIMARY KEY,
    version_id     INTEGER NOT NULL REFERENCES hz_index_version(id) ON DELETE CASCADE,
    course_id      INTEGER NOT NULL,
    resource_id    TEXT NOT NULL,
    resource_name  TEXT NOT NULL,
    resource_url   TEXT,
    resource_type  TEXT,
    chunk_index    INTEGER NOT NULL,
    content        TEXT NOT NULL,
    embedding      vector(1024) NOT NULL
);
CREATE INDEX IF NOT EXISTS hz_chunk_course ON hz_chunk (course_id, version_id);
CREATE INDEX IF NOT EXISTS hz_chunk_embedding ON hz_chunk USING hnsw (embedding vector_cosine_ops);

-- Registro disociado (sin usuario) de consulta, contexto y respuesta para RAGAS.
CREATE TABLE IF NOT EXISTS hz_interaction (
    id          BIGSERIAL PRIMARY KEY,
    course_id   INTEGER NOT NULL,
    question    TEXT NOT NULL,
    answer      TEXT,
    contexts    JSONB,
    sources     JSONB,
    max_score   REAL,
    status      TEXT,
    created_at  TIMESTAMPTZ DEFAULT now()
);
