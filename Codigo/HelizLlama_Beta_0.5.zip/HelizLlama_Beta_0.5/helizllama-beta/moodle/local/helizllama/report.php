<?php
/**
 * Panel de seguimiento docente con registros disociados (HU-06).
 *
 * @package    local_helizllama
 * @copyright  2026 Jairo Ramírez, Brandon Acurio
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require(__DIR__ . '/../../config.php');

$courseid = required_param('courseid', PARAM_INT);
$course = get_course($courseid);
require_login($course);
$context = context_course::instance($courseid);
require_capability('local/helizllama:viewreports', $context);

$PAGE->set_url(new moodle_url('/local/helizllama/report.php', ['courseid' => $courseid]));
$PAGE->set_context($context);
$PAGE->set_pagelayout('incourse');
$PAGE->set_title(get_string('reporttitle', 'local_helizllama'));
$PAGE->set_heading(format_string($course->fullname));

$counts = $DB->get_record_sql("SELECT COUNT(1) AS total,
        SUM(CASE WHEN status = 'ok' THEN 1 ELSE 0 END) AS answered,
        SUM(CASE WHEN status = 'no_context' THEN 1 ELSE 0 END) AS nocontext,
        SUM(CASE WHEN status = 'out_of_scope' THEN 1 ELSE 0 END) AS outofscope,
        SUM(CASE WHEN status = 'error' THEN 1 ELSE 0 END) AS errors,
        SUM(CASE WHEN feedback = 1 THEN 1 ELSE 0 END) AS useful,
        SUM(CASE WHEN feedback = 0 THEN 1 ELSE 0 END) AS notuseful,
        AVG(latencyms) AS latency
      FROM {local_helizllama_log} WHERE courseid = ?", [$courseid]);

echo $OUTPUT->header();
echo $OUTPUT->heading(get_string('reporttitle', 'local_helizllama'));
echo html_writer::tag('p', get_string('reportprivacy', 'local_helizllama'), ['class' => 'text-muted']);

$summary = new html_table();
$summary->head = [get_string('total', 'local_helizllama'), get_string('answered', 'local_helizllama'),
    get_string('nocontext', 'local_helizllama'), get_string('outofscope', 'local_helizllama'),
    get_string('errors', 'local_helizllama'), get_string('useful', 'local_helizllama'),
    get_string('notuseful', 'local_helizllama'), get_string('avglatency', 'local_helizllama')];
$summary->data = [[(int)$counts->total, (int)$counts->answered, (int)$counts->nocontext, (int)$counts->outofscope,
    (int)$counts->errors, (int)$counts->useful, (int)$counts->notuseful,
    $counts->latency ? round($counts->latency / 1000, 1) . ' s' : '-']];
echo html_writer::table($summary);

$logs = $DB->get_records('local_helizllama_log', ['courseid' => $courseid], 'timecreated DESC',
    'id, question, status, latencyms, feedback, timecreated', 0, 200);
$table = new html_table();
$table->head = [get_string('date'), get_string('question', 'local_helizllama'), get_string('status', 'local_helizllama'),
    get_string('latency', 'local_helizllama'), get_string('feedback', 'local_helizllama')];
foreach ($logs as $log) {
    $fb = $log->feedback === null ? '-' : ($log->feedback ? get_string('useful', 'local_helizllama')
                                                           : get_string('notuseful', 'local_helizllama'));
    $table->data[] = [userdate($log->timecreated, get_string('strftimedatetimeshort', 'langconfig')), s($log->question),
        s($log->status), $log->latencyms ? round($log->latencyms / 1000, 1) . ' s' : '-', $fb];
}
echo html_writer::table($table);
echo $OUTPUT->footer();
