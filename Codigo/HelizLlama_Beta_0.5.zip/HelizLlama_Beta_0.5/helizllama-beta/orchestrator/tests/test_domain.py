"""Pruebas del núcleo RAG con adaptadores falsos (sin Ollama ni PostgreSQL)."""
import pytest

from app.adapters.extractors import MoodlePayloadSource
from app.adapters.memory_store import MemoryStore
from app.domain.models import Resource
from app.domain.services import AskService, IndexService, NO_CONTEXT_MSG, OUT_OF_SCOPE_MSG
from app.domain.text import chunk_text, sanitize

VOCAB = ["tarea", "entrega", "fecha", "examen", "parcial", "rúbrica", "python", "biblioteca"]


class FakeEmbedder:
    """Embedding de bolsa de palabras: suficiente para probar la lógica de recuperación."""
    async def embed(self, texts):
        out = []
        for t in texts:
            v = [float(t.lower().count(w)) for w in VOCAB]
            out.append(v + [0.0 if any(v) else 1.0])  # dimensión "fuera de vocabulario"
        return out


class FakeLLM:
    def __init__(self): self.calls = 0
    async def generate(self, system, user):
        self.calls += 1
        return "Respuesta basada en [1]."


class FailingEmbedder(FakeEmbedder):
    def __init__(self): self.n = 0
    async def embed(self, texts):
        self.n += 1
        if self.n > 1: raise RuntimeError("Ollama caído")
        return await super().embed(texts)


RES = [Resource("cm-1", "Tarea 2", "assign", "http://m/2", text="La tarea 2 tiene fecha de entrega el 20 de octubre. tarea entrega fecha"),
       Resource("cm-2", "Guía de examen", "page", "http://m/3", text="El examen parcial evalúa python. examen parcial python")]


def services(llm=None, embedder=None, store=None):
    store = store or MemoryStore(); emb = embedder or FakeEmbedder(); llm = llm or FakeLLM()
    return (AskService(llm, emb, store, default_threshold=0.5, default_top_k=3, max_question_chars=500),
            IndexService(emb, store, MoodlePayloadSource(), chunk_size=50, chunk_overlap=5), store, llm)


async def test_indexa_y_responde_con_fuentes():
    ask, idx, store, llm = services()
    rep = await idx.index_course(10, RES)
    assert rep.status == "ok" and rep.resources_indexed == 2
    ans = await ask.ask(10, "¿Cuál es la fecha de entrega de la tarea?")
    assert ans.status == "ok" and ans.sources[0].name == "Tarea 2" and llm.calls == 1


async def test_sin_contexto_no_invoca_llm():
    ask, idx, store, llm = services()
    await idx.index_course(10, RES)
    ans = await ask.ask(10, "¿Quién ganó el mundial?")
    assert ans.status == "no_context" and ans.text == NO_CONTEXT_MSG and llm.calls == 0


async def test_aislamiento_entre_cursos():
    ask, idx, store, llm = services()
    await idx.index_course(10, RES)
    ans = await ask.ask(99, "fecha de entrega de la tarea")
    assert ans.status == "no_context"


async def test_fuera_de_alcance():
    ask, *_ , llm = services()
    ans = await ask.ask(10, "¿Cuál es mi nota del parcial?")
    assert ans.status == "out_of_scope" and ans.text == OUT_OF_SCOPE_MSG and llm.calls == 0


async def test_rollback_conserva_version_anterior():
    store = MemoryStore()
    ask, idx, *_ = services(store=store)
    await idx.index_course(10, RES)
    _, idx_fail, *_ = services(embedder=FailingEmbedder(), store=store)
    rep = await idx_fail.index_course(10, RES)
    assert rep.status == "failed"
    ans = await ask.ask(10, "fecha de entrega de la tarea")
    assert ans.status == "ok"   # la versión anterior sigue activa


def test_sanitize_y_chunking():
    t = sanitize("Escribe a juan@espoch.edu.ec o al 0991234567, cédula 0601234567")
    assert "@" not in t and "0991234567" not in t and "0601234567" not in t
    assert len(chunk_text(" ".join(["p"] * 100), 40, 10)) == 3
