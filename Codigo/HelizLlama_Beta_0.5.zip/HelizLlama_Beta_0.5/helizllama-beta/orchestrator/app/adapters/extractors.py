"""ContentSourcePort: extrae texto de páginas HTML, PDF, DOCX y TXT enviados por Moodle."""
import base64
import io
import re
from html import unescape

from ..domain.models import Resource

_TAGS = re.compile(r"<(script|style)[^>]*>.*?</\1>|<[^>]+>", re.S | re.I)


def html_to_text(html: str) -> str:
    html = re.sub(r"<\s*(br|/p|/div|/li|/h\d)\s*/?>", "\n", html, flags=re.I)
    return unescape(_TAGS.sub(" ", html))


class MoodlePayloadSource:
    def __init__(self, max_file_mb: int = 15):
        self.max_bytes = max_file_mb * 1024 * 1024

    def extract_text(self, resource: Resource) -> str:
        parts = [resource.name]
        if resource.text:
            parts.append(html_to_text(resource.text))
        if resource.content_b64:
            data = base64.b64decode(resource.content_b64)
            if len(data) > self.max_bytes:
                raise ValueError("archivo demasiado grande")
            parts.append(self._file_text(data, resource.mimetype, resource.filename))
        return "\n".join(p for p in parts if p and p.strip())

    @staticmethod
    def _file_text(data: bytes, mimetype: str, filename: str) -> str:
        name = filename.lower()
        if mimetype == "application/pdf" or name.endswith(".pdf"):
            from pypdf import PdfReader
            return "\n".join((page.extract_text() or "") for page in PdfReader(io.BytesIO(data)).pages)
        if name.endswith(".docx"):
            from docx import Document
            return "\n".join(p.text for p in Document(io.BytesIO(data)).paragraphs)
        if mimetype.startswith("text/html") or name.endswith((".html", ".htm")):
            return html_to_text(data.decode("utf-8", errors="ignore"))
        if mimetype.startswith("text/") or name.endswith((".txt", ".md")):
            return data.decode("utf-8", errors="ignore")
        raise ValueError(f"tipo de archivo no soportado: {mimetype or filename}")
