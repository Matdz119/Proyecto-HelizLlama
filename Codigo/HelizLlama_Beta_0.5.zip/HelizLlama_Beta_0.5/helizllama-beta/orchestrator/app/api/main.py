"""Fachada REST del orquestador: /v1/health, /v1/models, /v1/ask, /v1/index."""
import asyncio
import logging
import secrets
import time
from contextlib import asynccontextmanager

from fastapi import Depends, FastAPI, Header, HTTPException
from pydantic import BaseModel, Field

from ..adapters.extractors import MoodlePayloadSource
from ..adapters.ollama import OllamaEmbedder, OllamaLLM, ollama_models
from ..adapters.pgvector_store import PgVectorStore
from ..config import settings
from ..domain.models import Resource
from ..domain.services import AskService, IndexService

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("helizllama.api")

store = PgVectorStore(settings.database_url)
llm = OllamaLLM(settings.ollama_url, settings.llm_model, settings.llm_temperature,
                settings.llm_num_ctx, settings.llm_timeout_s)
embedder = OllamaEmbedder(settings.ollama_url, settings.embed_model)
ask_service = AskService(llm, embedder, store, settings.similarity_threshold, settings.top_k,
                         settings.max_question_chars)
index_service = IndexService(embedder, store, MoodlePayloadSource(settings.max_file_mb),
                             settings.chunk_size_words, settings.chunk_overlap_words)
inference_slots = asyncio.Semaphore(settings.max_concurrent_inferences)  # cola de inferencia
index_lock = asyncio.Lock()  # una indexación a la vez para no saturar la GPU


@asynccontextmanager
async def lifespan(_: FastAPI):
    await store.open()
    yield
    await store.close()


app = FastAPI(title="HelizLlama RAG Orchestrator", version="0.5.0-beta", lifespan=lifespan)


def require_token(authorization: str = Header(default="")) -> None:
    expected = f"Bearer {settings.api_token}"
    if not secrets.compare_digest(authorization.encode(), expected.encode()):
        raise HTTPException(status_code=401, detail="Token inválido")


class AskIn(BaseModel):
    course_id: int = Field(gt=0)
    question: str = Field(min_length=1, max_length=4000)
    threshold: float | None = Field(default=None, ge=0, le=1)
    top_k: int | None = Field(default=None, ge=1, le=20)


class ResourceIn(BaseModel):
    resource_id: str
    name: str
    type: str
    url: str = ""
    text: str = ""
    filename: str = ""
    mimetype: str = ""
    content_b64: str = ""


class IndexIn(BaseModel):
    course_id: int = Field(gt=0)
    resources: list[ResourceIn]


@app.get("/v1/health")
async def health():
    status = {"orchestrator": "ok"}
    try:
        await store.ping(); status["database"] = "ok"
    except Exception as exc:
        status["database"] = f"error: {exc.__class__.__name__}"
    try:
        models = await ollama_models(settings.ollama_url)
        status["ollama"] = "ok"
        status["models_ready"] = all(any(m.startswith(x) for m in models)
                                     for x in (settings.llm_model, settings.embed_model))
    except Exception as exc:
        status["ollama"] = f"error: {exc.__class__.__name__}"
    return status


@app.get("/v1/models", dependencies=[Depends(require_token)])
async def models():
    return {"llm": settings.llm_model, "embeddings": settings.embed_model,
            "available": await ollama_models(settings.ollama_url)}


@app.post("/v1/ask", dependencies=[Depends(require_token)])
async def ask(body: AskIn):
    start = time.perf_counter()
    try:
        await asyncio.wait_for(inference_slots.acquire(), timeout=settings.queue_wait_s)
    except asyncio.TimeoutError:
        raise HTTPException(status_code=503, detail="El asistente está ocupado, intenta de nuevo")
    try:
        answer = await ask_service.ask(body.course_id, body.question, body.threshold, body.top_k)
    except Exception:
        log.exception("Fallo en /v1/ask")
        raise HTTPException(status_code=502, detail="No se pudo generar la respuesta")
    finally:
        inference_slots.release()
    return {"status": answer.status, "answer": answer.text,
            "sources": [s.__dict__ for s in answer.sources],
            "max_score": round(answer.max_score, 4),
            "latency_ms": int((time.perf_counter() - start) * 1000)}


@app.post("/v1/index", dependencies=[Depends(require_token)])
async def index(body: IndexIn):
    async with index_lock:
        report = await index_service.index_course(body.course_id, [Resource(**r.model_dump()) for r in body.resources])
    return report.__dict__


@app.get("/v1/index/{course_id}", dependencies=[Depends(require_token)])
async def index_status(course_id: int):
    return await store.course_status(course_id)
