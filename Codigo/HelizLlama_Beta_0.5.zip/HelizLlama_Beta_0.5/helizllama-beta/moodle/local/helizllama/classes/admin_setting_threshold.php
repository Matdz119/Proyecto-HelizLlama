<?php
/**
 * Ajuste del umbral de similitud con validación de rango 0..1.
 *
 * @package    local_helizllama
 * @copyright  2026 Jairo Ramírez, Brandon Acurio
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_helizllama;

defined('MOODLE_INTERNAL') || die();

require_once($CFG->libdir . '/adminlib.php');

class admin_setting_threshold extends \admin_setting_configtext {
    public function __construct($name, $visiblename, $description, $defaultsetting) {
        parent::__construct($name, $visiblename, $description, $defaultsetting, PARAM_RAW, 6);
    }

    public function validate($data) {
        $data = str_replace(',', '.', trim($data));
        if (!is_numeric($data) || (float)$data < 0 || (float)$data > 1) {
            return get_string('threshold_invalid', 'local_helizllama');
        }
        return true;
    }
}
