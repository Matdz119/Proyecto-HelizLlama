<?php
/**
 * @package    local_helizllama
 * @copyright  2026 Jairo Ramírez, Brandon Acurio
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_helizllama\task;

use local_helizllama\index_manager;

defined('MOODLE_INTERNAL') || die();

/**
 * Tarea programada diaria: reindexa los cursos con el asistente activo que nunca se indexaron
 * o que tienen cambios pendientes (por ejemplo, si falló una tarea ad hoc).
 */
class daily_sync extends \core\task\scheduled_task {
    public function get_name() {
        return get_string('taskdailysync', 'local_helizllama');
    }

    public function execute() {
        global $DB;
        $sql = "SELECT DISTINCT ctx.instanceid AS courseid
                  FROM {block_instances} bi
                  JOIN {context} ctx ON ctx.id = bi.parentcontextid AND ctx.contextlevel = :level
                 WHERE bi.blockname = 'helizllama'";
        $courses = $DB->get_fieldset_sql($sql, ['level' => CONTEXT_COURSE]);
        foreach ($courses as $courseid) {
            $rec = index_manager::get((int)$courseid);
            if ($rec->dirty || !$rec->lastindexed) {
                index_manager::queue((int)$courseid);
                mtrace("HelizLlama: curso $courseid encolado para reindexación");
            }
        }
    }
}
