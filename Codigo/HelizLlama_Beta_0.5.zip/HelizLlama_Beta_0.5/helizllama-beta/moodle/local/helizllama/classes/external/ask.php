<?php
/**
 * @package    local_helizllama
 * @copyright  2026 Jairo Ramírez, Brandon Acurio
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_helizllama\external;

use core_external\external_api;
use core_external\external_function_parameters;
use core_external\external_multiple_structure;
use core_external\external_single_structure;
use core_external\external_value;
use local_helizllama\client;

defined('MOODLE_INTERNAL') || die();

/**
 * Servicio externo ask: valida sesión y capacidad, consulta al orquestador y guarda el registro disociado.
 */
class ask extends external_api {
    public static function execute_parameters(): external_function_parameters {
        return new external_function_parameters([
            'courseid' => new external_value(PARAM_INT, 'ID del curso'),
            'question' => new external_value(PARAM_TEXT, 'Pregunta en lenguaje natural'),
        ]);
    }

    public static function execute(int $courseid, string $question): array {
        global $DB, $SESSION;
        $params = self::validate_parameters(self::execute_parameters(), ['courseid' => $courseid, 'question' => $question]);
        $context = \context_course::instance($params['courseid']);
        self::validate_context($context);
        require_capability('local/helizllama:use', $context);

        $question = \core_text::substr(trim($params['question']), 0, 1000);
        $result = ['status' => 'error', 'answer' => get_string('unavailable', 'local_helizllama'),
            'sources' => [], 'max_score' => null, 'latency_ms' => null];
        try {
            $result = (new client())->request('POST', '/v1/ask', [
                'course_id' => $params['courseid'],
                'question' => $question,
                'threshold' => (float)str_replace(',', '.', (string)get_config('local_helizllama', 'threshold')),
                'top_k' => (int)get_config('local_helizllama', 'topk') ?: 5,
            ]) + $result;
        } catch (\moodle_exception $e) {
            // RF-09: el curso sigue operativo; se informa al usuario y se registra el incidente.
            debugging('HelizLlama: ' . $e->getMessage() . ' ' . ($e->debuginfo ?? ''), DEBUG_NORMAL);
        }

        $sources = [];
        foreach ((array)$result['sources'] as $s) {
            $sources[] = ['name' => (string)($s['name'] ?? ''), 'url' => clean_param((string)($s['url'] ?? ''), PARAM_URL)];
        }
        $logid = $DB->insert_record('local_helizllama_log', (object)[
            'courseid' => $params['courseid'],
            'question' => $question,
            'answer' => (string)$result['answer'],
            'sources' => json_encode($sources, JSON_UNESCAPED_UNICODE),
            'status' => clean_param((string)$result['status'], PARAM_ALPHAEXT),
            'maxscore' => $result['max_score'],
            'latencyms' => $result['latency_ms'],
            'timecreated' => time(),
        ]);
        // Solo quien hizo la consulta, en su sesión, puede valorarla.
        $SESSION->local_helizllama_logs = array_merge($SESSION->local_helizllama_logs ?? [], [$logid]);

        return ['logid' => $logid, 'status' => (string)$result['status'], 'answer' => (string)$result['answer'],
            'sources' => $sources];
    }

    public static function execute_returns(): external_single_structure {
        return new external_single_structure([
            'logid' => new external_value(PARAM_INT, 'ID del registro disociado'),
            'status' => new external_value(PARAM_ALPHAEXT, 'ok, no_context, out_of_scope, rejected o error'),
            'answer' => new external_value(PARAM_RAW, 'Respuesta en texto plano'),
            'sources' => new external_multiple_structure(new external_single_structure([
                'name' => new external_value(PARAM_TEXT, 'Nombre del recurso'),
                'url' => new external_value(PARAM_URL, 'Enlace al recurso', VALUE_OPTIONAL),
            ])),
        ]);
    }
}
