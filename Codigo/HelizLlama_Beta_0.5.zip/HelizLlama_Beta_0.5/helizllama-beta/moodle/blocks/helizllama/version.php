<?php
/**
 * HelizLlama - panel conversacional del curso.
 *
 * @package    block_helizllama
 * @copyright  2026 Jairo Ramírez, Brandon Acurio
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$plugin->component = 'block_helizllama';
$plugin->version   = 2026102000;
$plugin->requires  = 2024100700;
$plugin->maturity  = MATURITY_BETA;
$plugin->release   = '0.5.0-beta';
$plugin->dependencies = ['local_helizllama' => 2026102000];
