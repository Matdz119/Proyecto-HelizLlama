<?php
/**
 * @package    local_helizllama
 * @copyright  2026 Jairo Ramírez, Brandon Acurio
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_helizllama\privacy;

use core_privacy\local\metadata\collection;
use core_privacy\local\request\approved_contextlist;
use core_privacy\local\request\contextlist;

defined('MOODLE_INTERNAL') || die();

/**
 * El plugin no guarda datos que identifiquen al usuario: los registros son disociados.
 * Sí envía el texto de la pregunta y el curso al orquestador, que se declara como ubicación externa.
 */
class provider implements \core_privacy\local\metadata\provider, \core_privacy\local\request\plugin\provider {
    public static function get_metadata(collection $collection): collection {
        $collection->add_external_location_link('helizllama_orchestrator', [
            'question' => 'privacy:metadata:orchestrator:question',
            'courseid' => 'privacy:metadata:orchestrator:courseid',
        ], 'privacy:metadata:orchestrator');
        return $collection;
    }

    public static function get_contexts_for_userid(int $userid): contextlist {
        return new contextlist();
    }

    public static function export_user_data(approved_contextlist $contextlist) {
    }

    public static function delete_data_for_all_users_in_context(\context $context) {
    }

    public static function delete_data_for_user(approved_contextlist $contextlist) {
    }
}
