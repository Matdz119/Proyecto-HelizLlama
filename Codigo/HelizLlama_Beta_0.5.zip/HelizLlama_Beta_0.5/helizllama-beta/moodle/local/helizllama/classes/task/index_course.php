<?php
/**
 * @package    local_helizllama
 * @copyright  2026 Jairo Ramírez, Brandon Acurio
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_helizllama\task;

use local_helizllama\client;
use local_helizllama\content_extractor;
use local_helizllama\index_manager;

defined('MOODLE_INTERNAL') || die();

/**
 * Tarea ad hoc: envía el contenido del curso al orquestador (POST /v1/index).
 * El orquestador escribe un índice en sombra y solo lo activa si termina sin errores.
 */
class index_course extends \core\task\adhoc_task {
    public function execute() {
        $courseid = (int)$this->get_custom_data()->courseid;
        index_manager::update($courseid, ['status' => 'running', 'dirty' => 0]);
        try {
            $resources = content_extractor::course_resources($courseid);
            mtrace("HelizLlama: indexando curso $courseid con " . count($resources) . " recursos");
            $report = (new client())->request('POST', '/v1/index',
                ['course_id' => $courseid, 'resources' => $resources], 1800);
            $ok = ($report['status'] ?? '') === 'ok';
            $skipped = $report['resources_skipped'] ?? [];
            index_manager::update($courseid, [
                'status' => $ok ? 'ok' : 'error',
                'resources' => (int)($report['resources_indexed'] ?? 0),
                'chunks' => (int)($report['chunks'] ?? 0),
                'lastindexed' => $ok ? time() : index_manager::get($courseid)->lastindexed,
                'dirty' => $ok ? 0 : 1,
                'message' => $ok ? ($skipped ? get_string('skipped', 'local_helizllama', implode(', ', $skipped)) : '')
                                 : (string)($report['message'] ?? ''),
            ]);
        } catch (\Throwable $e) {
            // El índice anterior sigue vigente; la tarea diaria volverá a intentarlo.
            index_manager::update($courseid, ['status' => 'error', 'dirty' => 1, 'message' => $e->getMessage()]);
            mtrace('HelizLlama: error al indexar el curso ' . $courseid . ': ' . $e->getMessage());
        }
    }
}
