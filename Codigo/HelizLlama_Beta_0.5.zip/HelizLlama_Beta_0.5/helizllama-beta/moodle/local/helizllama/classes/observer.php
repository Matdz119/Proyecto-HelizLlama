<?php
/**
 * Observador de cambios del curso: marca el curso y encola la reindexación asíncrona.
 *
 * @package    local_helizllama
 * @copyright  2026 Jairo Ramírez, Brandon Acurio
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_helizllama;

defined('MOODLE_INTERNAL') || die();

class observer {
    /**
     * Cualquier cambio de contenido en un curso con el asistente activo encola una tarea ad hoc.
     * La tarea se deduplica, así que varios cambios seguidos generan una sola reindexación.
     */
    public static function content_changed(\core\event\base $event): void {
        $courseid = (int)$event->courseid;
        if ($courseid <= SITEID || !index_manager::assistant_enabled($courseid)) {
            return;
        }
        index_manager::mark_dirty($courseid);
        index_manager::queue($courseid);
    }
}
