<?php
/**
 * Ajustes del sitio de local_helizllama (HU-04).
 *
 * @package    local_helizllama
 * @copyright  2026 Jairo Ramírez, Brandon Acurio
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

if ($hassiteconfig) {
    $settings = new admin_settingpage('local_helizllama', get_string('pluginname', 'local_helizllama'));
    $ADMIN->add('localplugins', $settings);

    $settings->add(new admin_setting_heading('local_helizllama/connection',
        get_string('connection', 'local_helizllama'), get_string('connection_desc', 'local_helizllama')));
    $settings->add(new admin_setting_configtext('local_helizllama/orchestratorurl',
        get_string('orchestratorurl', 'local_helizllama'), get_string('orchestratorurl_desc', 'local_helizllama'),
        'http://100.64.0.1:8000', PARAM_URL));
    $settings->add(new admin_setting_configpasswordunmask('local_helizllama/apitoken',
        get_string('apitoken', 'local_helizllama'), get_string('apitoken_desc', 'local_helizllama'), ''));
    $settings->add(new admin_setting_configtext('local_helizllama/timeout',
        get_string('timeout', 'local_helizllama'), get_string('timeout_desc', 'local_helizllama'), 90, PARAM_INT));

    $settings->add(new admin_setting_heading('local_helizllama/retrieval',
        get_string('retrieval', 'local_helizllama'), ''));
    $settings->add(new \local_helizllama\admin_setting_threshold('local_helizllama/threshold',
        get_string('threshold', 'local_helizllama'), get_string('threshold_desc', 'local_helizllama'), '0.45'));
    $settings->add(new admin_setting_configtext('local_helizllama/topk',
        get_string('topk', 'local_helizllama'), get_string('topk_desc', 'local_helizllama'), 5, PARAM_INT));
    $settings->add(new admin_setting_configtext('local_helizllama/maxfilemb',
        get_string('maxfilemb', 'local_helizllama'), get_string('maxfilemb_desc', 'local_helizllama'), 10, PARAM_INT));

    $settings->add(new admin_setting_description('local_helizllama/healthlink', '',
        html_writer::link(new moodle_url('/local/helizllama/health.php'), get_string('checkhealth', 'local_helizllama'))));
}
