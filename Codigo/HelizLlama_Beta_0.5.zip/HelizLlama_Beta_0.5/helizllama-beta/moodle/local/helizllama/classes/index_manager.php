<?php
/**
 * Estado del índice por curso y encolado de tareas de indexación.
 *
 * @package    local_helizllama
 * @copyright  2026 Jairo Ramírez, Brandon Acurio
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_helizllama;

defined('MOODLE_INTERNAL') || die();

class index_manager {
    const TABLE = 'local_helizllama_index';

    /** El asistente está activo en un curso si tiene una instancia de block_helizllama. */
    public static function assistant_enabled(int $courseid): bool {
        global $DB;
        $context = \context_course::instance($courseid, IGNORE_MISSING);
        if (!$context) {
            return false;
        }
        return $DB->record_exists('block_instances', ['blockname' => 'helizllama', 'parentcontextid' => $context->id]);
    }

    public static function get(int $courseid): \stdClass {
        global $DB;
        $rec = $DB->get_record(self::TABLE, ['courseid' => $courseid]);
        if (!$rec) {
            $rec = (object)['courseid' => $courseid, 'status' => 'pending', 'dirty' => 0, 'resources' => 0,
                'chunks' => 0, 'message' => '', 'lastindexed' => 0, 'timemodified' => time()];
            $rec->id = $DB->insert_record(self::TABLE, $rec);
        }
        return $rec;
    }

    public static function update(int $courseid, array $fields): void {
        global $DB;
        $rec = self::get($courseid);
        foreach ($fields as $k => $v) {
            $rec->$k = $v;
        }
        $rec->timemodified = time();
        $DB->update_record(self::TABLE, $rec);
    }

    public static function mark_dirty(int $courseid): void {
        self::update($courseid, ['dirty' => 1]);
    }

    /** Encola la tarea ad hoc; queue_adhoc_task(..., true) evita duplicados. */
    public static function queue(int $courseid): void {
        $task = new task\index_course();
        $task->set_custom_data(['courseid' => $courseid]);
        $task->set_component('local_helizllama');
        \core\task\manager::queue_adhoc_task($task, true);
        self::update($courseid, ['status' => 'queued']);
    }
}
