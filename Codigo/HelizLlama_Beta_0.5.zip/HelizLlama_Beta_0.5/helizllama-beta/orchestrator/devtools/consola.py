"""Consola de pruebas de HelizLlama (solo desarrollo).

Usa el MISMO núcleo RAG del orquestador (AskService, IndexService, prompt, umbral),
pero con un almacén en memoria: no necesita Docker, PostgreSQL ni Moodle.

Ejecutar desde la carpeta orchestrator:
    python -m uvicorn devtools.consola:app --port 8090
y abrir http://localhost:8090
"""
import os
import time
from pathlib import Path

import httpx
from fastapi import FastAPI
from fastapi.responses import HTMLResponse
from pydantic import BaseModel

from app.adapters.extractors import MoodlePayloadSource
from app.adapters.memory_store import MemoryStore
from app.adapters.ollama import OllamaEmbedder, OllamaLLM
from app.domain.models import Resource
from app.domain.services import AskService, IndexService

OLLAMA_URL = os.getenv("HZ_OLLAMA_URL", "http://localhost:11434").rstrip("/")
LLM_MODEL = os.getenv("HZ_LLM_MODEL", "mistral")
EMBED_MODEL = os.getenv("HZ_EMBED_MODEL", "bge-m3")
COURSE_ID = 1

store = MemoryStore()
llm = OllamaLLM(OLLAMA_URL, LLM_MODEL, temperature=0.2, num_ctx=8192, timeout=180)
embedder = OllamaEmbedder(OLLAMA_URL, EMBED_MODEL)
ask_service = AskService(llm, embedder, store, default_threshold=0.45, default_top_k=5, max_question_chars=1000)
index_service = IndexService(embedder, store, MoodlePayloadSource(), chunk_size=220, chunk_overlap=40)

app = FastAPI(title="Consola HelizLlama")


class IndexIn(BaseModel):
    name: str = "Contenido de prueba"
    text: str


class AskIn(BaseModel):
    question: str
    threshold: float = 0.45
    direct: bool = False   # True: pregunta directa a Mistral sin RAG


@app.get("/", response_class=HTMLResponse)
def page():
    return (Path(__file__).parent / "consola.html").read_text(encoding="utf-8")


@app.get("/status")
async def status():
    info = {"ollama_url": OLLAMA_URL, "llm_model": LLM_MODEL, "embed_model": EMBED_MODEL,
            "ollama": False, "models": [], "llm_ready": False, "embed_ready": False,
            "indexed_chunks": sum(len(c) for v, c in store.chunks.items()
                                  if store.versions[v]["status"] == "active")}
    try:
        t0 = time.perf_counter()
        async with httpx.AsyncClient(timeout=5) as client:
            r = await client.get(f"{OLLAMA_URL}/api/tags")
            r.raise_for_status()
        info["latency_ms"] = int((time.perf_counter() - t0) * 1000)
        info["ollama"] = True
        info["models"] = [m["name"] for m in r.json().get("models", [])]
        info["llm_ready"] = any(m.startswith(LLM_MODEL) for m in info["models"])
        info["embed_ready"] = any(m.startswith(EMBED_MODEL) for m in info["models"])
    except Exception as exc:
        info["error"] = f"{exc.__class__.__name__}: {exc}"
    return info


@app.post("/index")
async def index(body: IndexIn):
    t0 = time.perf_counter()
    report = await index_service.index_course(COURSE_ID, [Resource("dev-1", body.name, "page", "", text=body.text)])
    return {**report.__dict__, "latency_ms": int((time.perf_counter() - t0) * 1000)}


@app.post("/ask")
async def ask(body: AskIn):
    t0 = time.perf_counter()
    try:
        if body.direct:
            text = await llm.generate("Responde en español, de forma breve.", body.question)
            result = {"status": "direct", "answer": text, "sources": [], "max_score": None}
        else:
            a = await ask_service.ask(COURSE_ID, body.question, threshold=body.threshold)
            result = {"status": a.status, "answer": a.text, "sources": [s.__dict__ for s in a.sources],
                      "max_score": round(a.max_score, 3)}
    except Exception as exc:
        result = {"status": "error", "answer": f"{exc.__class__.__name__}: {exc}", "sources": [], "max_score": None}
    result["latency_ms"] = int((time.perf_counter() - t0) * 1000)
    return result
