<?php
/**
 * Verificación del estado del orquestador, Ollama y la base vectorial (RF-16).
 *
 * @package    local_helizllama
 * @copyright  2026 Jairo Ramírez, Brandon Acurio
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require(__DIR__ . '/../../config.php');

require_login();
require_capability('moodle/site:config', context_system::instance());
$PAGE->set_context(context_system::instance());
$PAGE->set_url(new moodle_url('/local/helizllama/health.php'));
$PAGE->set_pagelayout('admin');
$PAGE->set_title(get_string('healthtitle', 'local_helizllama'));

echo $OUTPUT->header();
echo $OUTPUT->heading(get_string('healthtitle', 'local_helizllama'));
try {
    $client = new \local_helizllama\client();
    $health = $client->request('GET', '/v1/health', null, 15);
    $models = $client->request('GET', '/v1/models', null, 15);
    $table = new html_table();
    foreach ($health as $k => $v) {
        $table->data[] = [s($k), s(is_bool($v) ? ($v ? 'true' : 'false') : (string)$v)];
    }
    $table->data[] = ['llm', s($models['llm'] ?? '')];
    $table->data[] = ['embeddings', s($models['embeddings'] ?? '')];
    $table->data[] = ['available', s(implode(', ', $models['available'] ?? []))];
    echo html_writer::table($table);
    echo $OUTPUT->notification(get_string('healthok', 'local_helizllama'), 'success');
} catch (\moodle_exception $e) {
    echo $OUTPUT->notification($e->getMessage() . ' ' . s($e->debuginfo ?? ''), 'error');
}
echo $OUTPUT->footer();
