<?php
/**
 * Strings for local_helizllama (en).
 *
 * @package    local_helizllama
 * @copyright  2026 Jairo Ramírez, Brandon Acurio
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['answered'] = 'Answered';
$string['apitoken'] = 'API token';
$string['apitoken_desc'] = 'Must match HZ_API_TOKEN in the orchestrator .env file.';
$string['assign_cutoff'] = 'Cut-off date: {$a}';
$string['assign_due'] = 'Due date: {$a}';
$string['assign_from'] = 'Submissions open: {$a}';
$string['assistantnotenabled'] = 'Add the HelizLlama block to this course to enable the assistant and automatic reindexing.';
$string['avglatency'] = 'Average time';
$string['cannotrate'] = 'You can only rate answers to your own questions in this session.';
$string['checkhealth'] = 'Check orchestrator status';
$string['chunks'] = 'Fragments';
$string['connection'] = 'Orchestrator connection';
$string['connection_desc'] = 'The plugin never calls Ollama directly: it talks only to the RAG orchestrator over the private network (Tailscale).';
$string['coursesummary'] = 'Course information';
$string['errors'] = 'Errors';
$string['feedback'] = 'Rating';
$string['healthok'] = 'The orchestrator responded correctly.';
$string['healthtitle'] = 'HelizLlama service status';
$string['helizllama:manageindex'] = 'Manage the HelizLlama course index';
$string['helizllama:use'] = 'Use the HelizLlama assistant';
$string['helizllama:viewreports'] = 'View HelizLlama usage reports';
$string['indexhelp'] = 'Indexing runs in the background and creates a new version of the index; if it fails, the previous version remains active.';
$string['indexnow'] = 'Index course content now';
$string['indexqueued'] = 'Indexing was queued. It will run with the next cron execution.';
$string['lastindexed'] = 'Last successful indexing';
$string['latency'] = 'Response time';
$string['managetitle'] = 'HelizLlama: course index';
$string['maxfilemb'] = 'Maximum file size (MB)';
$string['maxfilemb_desc'] = 'Larger PDF or DOCX files are not indexed.';
$string['message'] = 'Message';
$string['never'] = 'Never';
$string['nocontext'] = 'Not in course';
$string['notconfigured'] = 'The orchestrator URL or token is not configured.';
$string['notuseful'] = 'Not useful';
$string['orchestratorerror'] = 'The orchestrator returned an error.';
$string['orchestratorunreachable'] = 'The orchestrator could not be reached.';
$string['orchestratorurl'] = 'Orchestrator URL';
$string['orchestratorurl_desc'] = 'Base URL of the FastAPI orchestrator, for example http://100.x.y.z:8000 (Tailscale IP).';
$string['outofscope'] = 'Out of scope';
$string['pendingchanges'] = 'Changes pending indexing';
$string['pluginname'] = 'HelizLlama assistant';
$string['privacy:metadata:orchestrator'] = 'The question text and course ID are sent to the HelizLlama RAG orchestrator (local server, no cloud services) to generate the answer. No user identifier is sent.';
$string['privacy:metadata:orchestrator:courseid'] = 'The course ID';
$string['privacy:metadata:orchestrator:question'] = 'The question asked';
$string['question'] = 'Question';
$string['quiz_close'] = 'Closes: {$a}';
$string['quiz_open'] = 'Opens: {$a}';
$string['reportprivacy'] = 'Questions are stored without any information that identifies the student.';
$string['reporttitle'] = 'HelizLlama: usage report';
$string['resources'] = 'Indexed resources';
$string['retrieval'] = 'Retrieval parameters';
$string['skipped'] = 'Skipped resources: {$a}';
$string['status'] = 'Status';
$string['status_error'] = 'Error (previous index still active)';
$string['status_ok'] = 'Up to date';
$string['status_pending'] = 'Not indexed';
$string['status_queued'] = 'Queued';
$string['status_running'] = 'Indexing';
$string['taskdailysync'] = 'HelizLlama daily index reconciliation';
$string['threshold'] = 'Similarity threshold';
$string['threshold_desc'] = 'Value between 0 and 1. Below it, the assistant declares that the information is not in the course and does not call the model.';
$string['threshold_invalid'] = 'The threshold must be a number between 0 and 1.';
$string['timeout'] = 'Timeout (seconds)';
$string['timeout_desc'] = 'Maximum wait for an answer before showing an error message.';
$string['topk'] = 'Fragments to retrieve (top-k)';
$string['topk_desc'] = 'Number of course fragments sent as context to the model.';
$string['total'] = 'Questions';
$string['unavailable'] = 'The assistant is not available right now. Please try again in a few minutes; the course works normally.';
$string['useful'] = 'Useful';
